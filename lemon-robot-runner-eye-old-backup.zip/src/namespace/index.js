import conn from './connector.js'
import globalLoading from './global-loading'

export default {
  CONNECTOR: conn,
  GLOBAL_LOADING: globalLoading
}
