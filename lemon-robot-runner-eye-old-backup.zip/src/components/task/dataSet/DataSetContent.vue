<template>
    <div></div>
</template>

<script>
export default {
  name: 'DataSetContentModule'
}
</script>

<style scoped>

</style>
